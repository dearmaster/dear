package com.leaf.captain.pic.domain;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.sql.Blob;
import java.util.Date;

public class Photo {

    private Integer id;
    @NotNull
    @Size(min = 2, max = 100)
    private String path;
    private Date uploadDate;
    private Integer uploaderId;
    private Blob content;

}