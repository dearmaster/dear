import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class TestGradleImport {

    private static final String customizedPath = "configuration/log4j.xml";

    static {
        System.setProperty("log4j.configuration", customizedPath);
    }

    private static final Logger logger = LogManager.getLogger(TestGradleImport.class);

    public static void main(String[] args) {
        logger.info("ok");
    }

}